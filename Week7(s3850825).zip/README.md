## Student detail
* Student ID: s3850825
* Name: You Chan Lee
* Github project url: https://github.com/s3850825/OSP-PrgAsg1-s3850825

## Code documentation

To run the application:

1. Unzip `Week7(s3850825).zip` file
2. Open a terminal where you unzip `Week7(s3850825).zip` file and type `make` in the terminal
3. Now, `Dining_Philosophers` and `Producer_Consumer` files are created
4. Type `valgrind ./Producer_Consumer` to run the Producer-Consumer problem
5. Type `valgrind ./Dining_Philosophers` to run the Dining Philosophers' problem
